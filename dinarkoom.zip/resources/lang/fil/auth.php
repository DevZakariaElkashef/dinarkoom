<?php

declare(strict_types=1);

return [
    'failed'   => 'Ang mga kredensyal na ito ay hindi tumutugma sa aming mga talaan.',
    'password' => 'Mali ang password.',
    'throttle' => 'Masyadong maraming mga pagtatangka sa pag-log in. Pakisubukang muli sa loob ng :seconds segundo.',
];
