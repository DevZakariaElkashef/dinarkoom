<?php

declare(strict_types=1);

return [
    'next'     => 'Susunod »',
    'previous' => '«Nakaraang',
];
