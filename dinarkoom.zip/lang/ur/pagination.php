<?php

declare(strict_types=1);

return [
    'next'     => 'آئندہ &raquo;',
    'previous' => '&laquo; گزشتہ',
];
